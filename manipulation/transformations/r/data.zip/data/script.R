data <- read.csv(file = "in/tables/cashier-data-predict.csv");

# Load the pre-computed model
load("in/user/predictionModel")

# Predict unknown values
predicted <- predict(fit, data, interval = "confidence")

# Write the results
df <- round(data.frame(data, predicted))
write.csv(df, file = "out/tables/data-predicted.csv", row.names = FALSE)