using Pkg
Pkg.add("DataFrames")
using CSV
using DataFrames

infile = "in/tables/source.csv"
outfile = "out/tables/destination.csv"
CSV.write(outfile, DataFrame(column1 = String[], column2 = String[]), writeheader = true)
for row in CSV.File(infile)
    # do something with row.column and write a new row
    row = DataFrame(column1 = row.first * "ping", column2 = row.second * 42)
    CSV.write(outfile, row, writeheader = false, append = true)
end
